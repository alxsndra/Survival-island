package PlayerClasses;

import Invertory.*;

public class Player {
    int health;
    Storage<Food> foodStorage;
    Storage<Water> waterStorage;
    Storage<Rock> rocksStorage;
    Storage<Wood> woodsStorage;

    public Player() {
        this.health = 100;
        this.foodStorage = new Storage<>();
        this.waterStorage = new Storage<>();
        this.rocksStorage = new Storage<>();
        this.woodsStorage = new Storage<>();
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public Storage<Food> getFoodStorage() {
        return foodStorage;
    }

    public void setFoodStorage(Storage<Food> foodStorage) {
        this.foodStorage = foodStorage;
    }

    public Storage<Water> getWaterStorage() {
        return waterStorage;
    }

    public void setWaterStorage(Storage<Water> waterStorage) {
        this.waterStorage = waterStorage;
    }

    public Storage<Rock> getRocksStorage() {
        return rocksStorage;
    }

    public void setRocksStorage(Storage<Rock> rocksStorage) {
        this.rocksStorage = rocksStorage;
    }

    public Storage<Wood> getWoodsStorage() {
        return woodsStorage;
    }

    public void setWoodsStorage(Storage<Wood> woodsStorage) {
        this.woodsStorage = woodsStorage;
    }
}
