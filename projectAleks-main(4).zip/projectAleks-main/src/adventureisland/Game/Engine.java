package Game;

import Functions.Functionalities;
import PlayerClasses.Player;

import java.util.Scanner;

import static Functions.Functionalities.*;

public class Engine implements Game{
    public Player player;
    public int[][] map;

    public void run() {
        this.map = generateMap(10);
        this.player = new Player();
        showMap(this.map);

        while(true) {
            Scanner scanner = new Scanner(System.in);
            int moveOption = scanner.nextInt();
            showMap(movePlayer(this.map, moveOption, player));
        }
    }

    @Override
    public void repaintMap() {

    }



}
