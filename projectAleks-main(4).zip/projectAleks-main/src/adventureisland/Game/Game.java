package Game;

public interface Game {
    public void run();
    public void repaintMap();
}
