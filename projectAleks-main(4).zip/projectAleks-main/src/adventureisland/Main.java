import Game.Engine;

import java.util.LinkedList;
import Functions.Functionalities;
import Functions.Objects;

public class Main {
//    public static void main(String[] args) {
//        Engine e = new Engine();
//        e.run();
////        System.out.println(Objects.TREE.ordinal());
//    }
}