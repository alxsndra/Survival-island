package Functions;

public enum Objects {
    TREE,
    RIVER,
    FOOD,
    MOUNTAIN,
    ROCK,
    STORM,
    WILD
}
