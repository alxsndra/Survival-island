package Functions;

import java.util.LinkedList;
import Functions.Objects;
import Invertory.Food;
import Invertory.Rock;
import Invertory.Water;
import Invertory.Wood;
import PlayerClasses.Player;

import java.util.Random;

public class Functionalities {
    private static int oldField;

    public static int[][] generateMap(int n) {
        int[][] map = new int[n][n];

        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[i].length; j++) {
                if (getRandomNum(0, 1) == 0) {
                    map[i][j] = 0;
                }
                else {
                    map[i][j] = getRandomNum(0, Objects.values().length);
                }
            }
        }

        int startingPosition = getRandomNum(1, n * n);
        int startI = startingPosition / n;
        int startJ = startingPosition % n;
        map[startI][startJ] = 8;


        return map;
    }

    public static void showMap(int[][] map) {
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[i].length; j++) {
                System.out.print(mapObject(map[i][j]) + "  ");
            }
            System.out.println();
        }
    }

    public static String mapToString(int[][] map) {
        String res = "";
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[i].length; j++) {
                res += mapObject(map[i][j]) + "  ";
            }
            if (i != map.length - 1) res += '\n';
        }
        
        return res;
    }
    
    private static String mapObject(int a) {
        switch (a) {
            case 0://pole
                return "🤣";
            case 1:
                return "🎄";
            case 2://river
                return "💧";
            case 3:
                return "🍕";
            case 4:
                return "🌄";
            case 5:
                return "⛰️";
            case 6://STORM
                return "🌁️";
            case 7://WILD
                return "🐯️";
            case 8:
                return "👨";
        }

        return "";
    }

    private static int getRandomNum(int start, int end) {
        Random random = new Random();

        return random.nextInt(end - start + 1) + start;
    }

    // 1 -> up 2 -> right 3 -> down 4 -> left
    public static int[][] movePlayer(int[][] map, int moveOption, Player player) {
        int newFieldI = 0, newFieldJ = 0;

        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[i].length; j++) {
                if (map[i][j] == 8) {
                    newFieldI = i;
                    newFieldJ = j;
                    switch (moveOption) {
                        case 1:
                            if (i == 0) return map;
                            newFieldI--;
                            break;
                        case 2:
                            if (j == map[i].length - 1) return map;
                            newFieldJ++;
                            break;
                        case 3:
                            if (i == map.length - 1) return map;
                            newFieldI++;
                            break;
                        case 4:
                            if (j == 0) return map;
                            newFieldJ--;
                            break;
                    }
                    int result = move(map[i][j], map[newFieldI][newFieldJ], player);
                    
                    if (result == 2) {
                        return map;
                    }
                    
                    if (oldField == 3 || oldField == 5 || oldField == 1) {
                        map[i][j] = 0;
                        oldField = 0;
                    }
                    else {
                        map[i][j] = oldField;
                        oldField = map[newFieldI][newFieldJ];
                    }
                    map[newFieldI][newFieldJ] = 8;
                    if (result == 0) {
                        System.out.println("GAME OVER");
                        return null;
                    }
                    return map;
                }
            }
        }
        return map;
    }

    private static int move(int playerPosition, int fieldToBeMovingTo, Player player) {
        if (fieldToBeMovingTo == 1) {//tree
            player.getWoodsStorage().add(new Wood());
        } else if (fieldToBeMovingTo == 2) {//river
            player.getWaterStorage().add(new Water());
        } else if (fieldToBeMovingTo == 3) {//food
            player.getFoodStorage().add(new Food());
        } else if (fieldToBeMovingTo == 5) {//rocks
            player.getRocksStorage().add(new Rock());
        } else if (fieldToBeMovingTo == 4) {//mountain
            return 2;
        } else if (fieldToBeMovingTo == 6 || fieldToBeMovingTo == 7) {
            return 0;
        }
        return 1;
    }
}
