package Invertory;

public class Rock {
}
