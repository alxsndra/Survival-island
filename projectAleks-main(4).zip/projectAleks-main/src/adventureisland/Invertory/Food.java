package Invertory;

public class Food {
}
