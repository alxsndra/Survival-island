package Invertory;

public class Water {
}
