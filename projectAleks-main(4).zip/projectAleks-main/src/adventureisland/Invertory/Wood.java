package Invertory;

public class Wood {
}
