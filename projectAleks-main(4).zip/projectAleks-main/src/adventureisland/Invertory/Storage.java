package Invertory;

import java.util.LinkedList;

public class Storage<E> {

    LinkedList<E> invertar;
    int count;

    public Storage() {
        this.invertar = new LinkedList<>();
        this.count = 0;
    }

    public int getCount() {
        return count;
    }

    public void add(E element) {
        this.invertar.add(element);
        this.count++;
    }

    public void remove(E element) {
        this.invertar.remove(element);
        this.count--;
    }

    public E get(int index) {
        return this.invertar.get(index);
    }
}
